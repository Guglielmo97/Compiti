// It should compile faster doing this way
#define CATCH_CONFIG_MAIN
#include "catch2/catch2.hpp"