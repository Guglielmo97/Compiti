//
// Created by olli on 04/05/20.
//

#include <cassert>
#include "../include/liblinalg/Vector.h"
#include "../include/liblinalg/Matrix.h"


Vector::Vector(int size, bool vertical): MatrixBase(size,1) {
    if(vertical == 0) {
        rows = 1;
        cols = size;

    }
    this->size = size;
}
Vector::Vector(double *data, int size, bool vertical):Vector(size,vertical){
    this->data = data;

}

double Vector::operator()(int i) const {

    return i;
}

double &Vector::operator()(int i) {
    return data[i];
}


Vector Vector::operator*(const Matrix &other) const {
        double *data1;
        data1 = MatrixBase::matrixMultiplication(other.getData(), other.getRows(), other.getCols());
        Vector p(data1, rows * other.getCols(),0);
        return p;
}

Matrix Vector::operator*(const Vector &other) const {
    if(cols == other.rows){
        double *data1 = new double[rows * other.getCols()];
        data1 = MatrixBase::matrixMultiplication(other.getData(), other.getRows(), other.getCols());
        Matrix P(data1, rows, other.getCols());
        return P;
    }
}


Vector Vector::operator+(const MatrixBase &other) const {
    Vector S(size);
    S.data= MatrixBase::matrixAddition(other.getData(), other.getRows(), other.getCols(), 1) ;
    return S;
}

Vector &Vector::operator+=(const MatrixBase &other) {
    data = MatrixBase::matrixAddition(other.getData(), other.getRows(), other.getCols(), 1) ;
    return *this;
}

Vector Vector::operator-(const MatrixBase &other) const {
    Vector D(size);
    D.data= MatrixBase::matrixAddition(other.getData(), other.getRows(), other.getCols(), 0) ;
    return D;
}

Vector &Vector::operator-=(const MatrixBase &other) {
    data = MatrixBase::matrixAddition(other.getData(), other.getRows(), other.getCols(), 0);
    return *this;
}

Vector &Vector::transposeInPlace() {
    int a=rows,b=cols;
    rows = b;
    cols = a;
    return *this;
}

Vector Vector::transpose() {
    Vector T(data, size);
    int a = T.rows;
    int b = T.cols;
    T.rows = b;
    T.cols = a;
    return T;
}
Vector &Vector::operator=(const Vector &other) {
    if(this != &other){
        for(int i=0;i<other.size;i++)
            data[i] = other.data[i];
    }
    return *this;
}

void Vector::resize(int size, bool vertical) {
    this->size = size;
    if (vertical == 0){
        this->rows = 1;
        this->cols = size;
    }
    else{
        this->rows = size;
        this->cols = 1;
    }

}











