//
// Created by olli on 04/05/20.
//
#include <iostream>
#include <cassert>
#include "../include/liblinalg/Matrix.h"
#include "../include/liblinalg/Vector.h"

using namespace std;
Matrix::Matrix(int rows, int cols) : MatrixBase(rows, cols) {}

Matrix::Matrix(double *data, int rows, int cols) : MatrixBase(data, rows, cols) {}


Matrix Matrix::operator*(const Matrix &other) const {
    Matrix P(rows,other.cols);
    P.data= MatrixBase::matrixMultiplication(other.getData(), other.getRows(), other.getCols());
    return P;
}

Vector Matrix::operator*(const Vector &other) const {
    if (other.getRows() == 1) {
        double *data1;
        data1 = MatrixBase::matrixMultiplication(other.getData(), cols, 1);
        Vector p(data1, other.getCols(),0);
        return p;
    }
    else  {
        double *data1;
        data1 = MatrixBase::matrixMultiplication(other.getData(), other.getCols(), 1);
        Vector p(data1, rows * other.getCols(),1);
        return p;
    }
}


Matrix Matrix::operator+(const MatrixBase &other) const {
    if(rows == other.getRows() && cols==other.getCols()) {
        double* data1;
        data1 = MatrixBase::matrixAddition(other.getData(), other.getRows(), other.getCols(), 1);
        Matrix S(data1, rows, cols);
        return S;
    }
}

Matrix &Matrix::operator+=(const MatrixBase &other) {
    data = MatrixBase::matrixAddition(other.getData(), other.getRows(), other.getCols(),1);
    return *this;
}

Matrix Matrix::operator-(const MatrixBase &other) const {
    if(rows == other.getRows() && cols==other.getCols()){}
    Matrix D(rows, cols);
    D.data = MatrixBase::matrixAddition(other.getData(), other.getRows(), other.getCols(),0);
    return D;
}

Matrix &Matrix::operator-=(const MatrixBase &other) {
    data = MatrixBase::matrixAddition(other.getData(), other.getRows(), other.getCols(),0);
    return *this;
}

Matrix &Matrix::transposeInPlace() {
    double T [size];
    for (int i = 0; i < size; ++i) {
        T[i] = data[i];
    }
    for (int j = 0; j < cols; ++j) {
        for (int k = 0; k < rows; ++k) {
            data[j * rows + k] = T[k * cols +j];
        }
    }
    int a = getRows();
    int b = getCols();
    cols = a;
    rows = b;
    return *this;

}

Matrix Matrix::transpose() {
    double Transpose [size];
    for (int i = 0; i < size; ++i) {
        Transpose[i] = data[i];
    }
    double *data1 = new double [size];
    Matrix T(data1, cols, rows);
    for (int j = 0; j < cols; ++j) {
        for (int k = 0; k < rows; ++k) {
            T.data[j * rows + k] = Transpose[k * cols + j];
        }
    }
    return T;
}

Matrix &Matrix::operator=(const Matrix &other) {
    if(this != &other){
        for(int i=0;i<other.size;i++)
            data[i] = other.data[i];
    }
    return *this;
}

void Matrix::resize(int rows, int cols) {
    this -> rows = rows;
    this -> cols = cols;

}



