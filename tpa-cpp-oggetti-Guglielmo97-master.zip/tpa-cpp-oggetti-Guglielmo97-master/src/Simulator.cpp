//
// Created by olli on 10/05/20.
//

#include "libsimcon/Simulator.h"

Simulator::Simulator(Matrix &A, Matrix &B, Vector &x0): A(0,0), B(0,0), x(0) {
    this-> A = A;
    this-> B = B;
    this-> x = x0;
}


void Simulator::simulate(Vector &u) {
    x = A * getX() + B * u;
}

const Vector &Simulator::getX() const {
    return x;
}

