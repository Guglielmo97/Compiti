//
// Created by olli on 10/05/20.
//

#include "libsimcon/Controller.h"

Controller::Controller(Matrix &K) : K(K) {

}


Vector Controller::control(const Vector &x) {
    Vector u(x.getSize());
    u = K * x;
    loopCount++;
    return u;
}

const Matrix &Controller::getK() const {

    return K;
}

void Controller::setK(const Matrix &k) {
    K = k;
}
