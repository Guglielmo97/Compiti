//
// Created by olli on 11/05/20.
//

#include "ClosedLoop.h"


void ClosedLoop::simulationStep() {

}

void ClosedLoop::completeSimulation(int nSteps) {
    for (int i = 0; i < nSteps; ++i) {
        ClosedLoop(s , c);

    }

}

Vector ClosedLoop::getState() const {
    return x;
}


