//
// Created by olli on 04/05/20.
//

#include <cassert>
#include <ios>
#include <iomanip>
#include <string>
#include <sstream>
#include <iostream>
#include <liblinalg/Matrix.h>
#include "../include/liblinalg/MatrixBase.h"
using namespace std;
MatrixBase::MatrixBase(int rows, int cols) {
    this->rows = rows;
    this->cols = cols;
    size = rows * cols;
    data = new double[size];
}

MatrixBase::MatrixBase(double *data, int rows, int cols):MatrixBase(rows,cols){
    this-> data = data;
}

MatrixBase::MatrixBase(const MatrixBase &other) {
    rows = other.rows;
    cols = other.cols;
    size = other.size;
    if (this != &other) {
        delete[] data;
        data = new double[other.size];
        for (int i = 0; i < size; i++) {
            data[i] = other.data[i];
        }
    }
}
double MatrixBase::operator()(int r, int c) const {
    return cols*r+c;
}

double &MatrixBase::operator()(int r, int c) {
    return data[cols*r+c];
}


void MatrixBase::setAllValuesAt(double value) {
    for(int i = 0; i < size;i++){
        data[i] = value;
    }

}

MatrixBase &MatrixBase::operator,(double val) {
    initIndex++;
    data[initIndex] = val;
    return *this;
}

MatrixBase &MatrixBase::operator<<=(double val) {
    initIndex = 0;
    data[initIndex] = val;
    return *this;
}

std::string MatrixBase::toString() const {
    std::stringstream stream ;
    for(int i = 0; i < size; ++i)
    {
        if(i != 0){
            stream << " ";}
        stream << std::fixed<<std::setprecision(2)<<data[i];
    }
    stream<<" \n";
    return stream.str();
}

double *MatrixBase::matrixMultiplication(const double *B, int rb, int cb) const {
    int i = 0;
    double *prod = new double [rows * cb];
    for (int j = 0; j < rows; ++j) {
        for (int k = 0; k < cb; ++k) {
            prod[j * cb + k] = 0;
            for (int l = 0; l < cols; ++l) {   //cols = rb
                prod[j * cb + k] = prod[j * cb + k] + data[l + j * cols] * B[l * cb + k];
            }
        }
    }
    return prod;
}

double *MatrixBase::matrixAddition(const double *B, int rb, int cb, bool sub) const {
    double *sum = new double [size];
    int i;
    for (i = 0; i < size; i++){
        if (sub == 1) {
            sum[i] = data[i] + B[i];
        }
        else sum[i] = data[i] - B[i];

    }

    return sum;
}

void MatrixBase::assignmentOperator(const MatrixBase &other) {
    if(this != &other) {
        for (int i = 0; i < other.size; i++){
            this->data = other.data;
            this->cols = other.cols;
            this ->rows = other.rows;
        }
    }
}








